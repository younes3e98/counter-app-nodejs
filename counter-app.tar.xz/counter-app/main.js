const express = require('express');
const session = require('express-session');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// Configurazione logging
const logFile = path.join(__dirname, 'counter-app.log');

function log(level, message, data = null) {
  const timestamp = new Date().toISOString();
  const logEntry = {
    timestamp,
    level,
    message,
    data,
    pid: process.pid,
    port: PORT
  };

  const logLine = `[${timestamp}] [${level}] [PID:${process.pid}] [PORT:${PORT}] ${message} ${data ? JSON.stringify(data) : ''}\n`;

  // Console log
  console.log(logLine.trim());

  // File log
  fs.appendFileSync(logFile, logLine);
}

// Log startup
log('INFO', 'Counter App Starting', { port: PORT, nodeVersion: process.version });

// Configurazione della sessione con isolamento per porta
const sessionName = `counter-app-${PORT}`; // Nome unico basato sulla porta
const sessionSecret = process.env.SESSION_SECRET || `counter-secret-key-${PORT}`;

app.use(session({
  name: sessionName, // Nome cookie specifico per questa istanza
  secret: sessionSecret, // Secret unico per questa istanza
  resave: false,
  saveUninitialized: true,
  cookie: {
    secure: false, // metti true se usi HTTPS
    maxAge: 24 * 60 * 60 * 1000, // 24 ore
    httpOnly: true, // Sicurezza aggiuntiva
    path: '/' // Assicura che il cookie sia disponibile per tutta l'app
  }
}));

log('INFO', 'Session configured with isolation', {
  sessionName: sessionName,
  port: PORT
});

// Middleware per logging delle richieste
app.use((req, res, next) => {
  const sessionId = req.session.id || 'NO-SESSION';
  log('REQUEST', `${req.method} ${req.url}`, {
    sessionId: sessionId,
    userAgent: req.get('User-Agent'),
    ip: req.ip
  });
  next();
});

// Middleware per logging degli errori
app.use((err, req, res, next) => {
  log('ERROR', 'Unhandled error', {
    error: err.message,
    stack: err.stack,
    sessionId: req.session?.id
  });
  res.status(500).json({ error: 'Internal server error' });
});

// Middleware per parsing JSON
app.use(express.json());
app.use(express.static('public'));

// Variabile globale per il counter condiviso (opzionale)
let globalCounter = 0;

// Route principale
app.get('/', (req, res) => {
  log('INFO', 'Serving main page', { sessionId: req.session.id });
  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
        <title>Counter App</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 600px;
                margin: 50px auto;
                text-align: center;
                background-color: ${PORT === 3000 ? '#f0f8ff' : PORT === 3100 ? '#fff8f0' : '#f5f5f5'};
            }
            .container {
                background: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                border-left: 5px solid ${PORT === 3000 ? '#3498db' : PORT === 3100 ? '#e67e22' : '#34495e'};
            }
            .counter {
                font-size: 3em;
                color: #2c3e50;
                margin: 20px 0;
            }
            button {
                font-size: 1.2em;
                padding: 10px 20px;
                margin: 5px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
            }
            .increment { background-color: #27ae60; color: white; }
            .decrement { background-color: #e74c3c; color: white; }
            .reset { background-color: #34495e; color: white; }
            .invalidate { background-color: #e67e22; color: white; }
            .collapsible {
                background-color: #3498db;
                color: white;
                cursor: pointer;
                padding: 10px 20px;
                border: none;
                border-radius: 5px;
                margin: 10px 0;
                font-size: 1em;
            }
            .collapsible:hover {
                background-color: #2980b9;
            }
            .content {
                display: none;
                padding: 15px;
                background-color: #ecf0f1;
                border-radius: 5px;
                margin-bottom: 10px;
                font-family: monospace;
                font-size: 0.8em;
                text-align: left;
                max-height: 300px;
                overflow-y: auto;
            }
            .content.active {
                display: block;
            }
            .info {
                margin-top: 30px;
                padding: 15px;
                background-color: #ecf0f1;
                border-radius: 5px;
                font-size: 0.9em;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Counter App per Test Load Balancing - Porta ${PORT}</h1>
            <div class="counter" id="counter">-</div>

            <button class="increment" onclick="updateCounter('increment')">+1</button>
            <button class="decrement" onclick="updateCounter('decrement')">-1</button>
            <button class="reset" onclick="updateCounter('reset')">Reset</button>
            <button class="invalidate" onclick="invalidateSession()">Invalida Sessione</button>

            <div class="info">
                <div><strong>Session ID:</strong> <span id="sessionId">-</span></div>
                <div><strong>Server PID:</strong> <span id="serverPid">-</span></div>
                <div><strong>Server Port:</strong> <span id="serverPort">-</span></div>
                <div><strong>Hostname:</strong> <span id="hostname">-</span></div>
                <div><strong>Counter Globale:</strong> <span id="globalCounter">-</span></div>
            </div>

            <button class="collapsible" onclick="toggleCollapsible()">🔧 Mostra Dettagli Tecnici</button>
            <div class="content" id="technicalDetails">
                <h4>Environment Variables:</h4>
                <div id="envVars">Caricamento...</div>

                <h4>Process Info:</h4>
                <div id="processInfo">Caricamento...</div>

                <h4>Server Stats:</h4>
                <div id="serverStats">Caricamento...</div>
            </div>
        </div>

        <script>
            async function updateCounter(action) {
                try {
                    const response = await fetch('/api/counter', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ action: action })
                    });

                    const data = await response.json();
                    updateUI(data);
                } catch (error) {
                    console.error('Errore:', error);
                }
            }

            async function invalidateSession() {
                try {
                    const response = await fetch('/api/session/invalidate', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    });

                    const data = await response.json();
                    if (data.success) {
                        alert('Sessione invalidata! Creata nuova sessione: ' + data.newSessionId);
                        loadCounter();
                        loadTechnicalDetails();
                    }
                } catch (error) {
                    console.error('Errore invalidazione sessione:', error);
                }
            }

            async function loadCounter() {
                try {
                    const response = await fetch('/api/counter');
                    const data = await response.json();
                    updateUI(data);
                } catch (error) {
                    console.error('Errore:', error);
                }
            }

            async function loadTechnicalDetails() {
                try {
                    const response = await fetch('/api/technical');
                    const data = await response.json();
                    updateTechnicalUI(data);
                } catch (error) {
                    console.error('Errore caricamento dettagli tecnici:', error);
                }
            }

            function updateUI(data) {
                document.getElementById('counter').textContent = data.sessionCounter;
                document.getElementById('sessionId').textContent = data.sessionId;
                document.getElementById('serverPid').textContent = data.serverInfo.pid;
                document.getElementById('serverPort').textContent = data.serverInfo.port;
                document.getElementById('hostname').textContent = data.serverInfo.hostname;
                document.getElementById('globalCounter').textContent = data.globalCounter;
            }

            function updateTechnicalUI(data) {
                // Environment Variables
                const envVarsEl = document.getElementById('envVars');
                let envHtml = '<pre>';
                for (const [key, value] of Object.entries(data.env)) {
                    envHtml += key + ': ' + value + '\\n';
                }
                envHtml += '</pre>';
                envVarsEl.innerHTML = envHtml;

                // Process Info
                const processInfoEl = document.getElementById('processInfo');
                const processInfo = '<pre>PID: ' + data.process.pid + '\\n' +
                    'Platform: ' + data.process.platform + '\\n' +
                    'Node Version: ' + data.process.version + '\\n' +
                    'Uptime: ' + Math.round(data.process.uptime) + ' seconds\\n' +
                    'Working Directory: ' + data.process.cwd + '\\n' +
                    'Executable Path: ' + data.process.execPath + '\\n' +
                    'Memory Usage:\\n' +
                    '  RSS: ' + Math.round(data.process.memoryUsage.rss / 1024 / 1024) + ' MB\\n' +
                    '  Heap Used: ' + Math.round(data.process.memoryUsage.heapUsed / 1024 / 1024) + ' MB\\n' +
                    '  Heap Total: ' + Math.round(data.process.memoryUsage.heapTotal / 1024 / 1024) + ' MB\\n' +
                    '  External: ' + Math.round(data.process.memoryUsage.external / 1024 / 1024) + ' MB\\n' +
                    'CPU Usage:\\n' +
                    '  User: ' + data.process.cpuUsage.user + ' microseconds\\n' +
                    '  System: ' + data.process.cpuUsage.system + ' microseconds</pre>';
                processInfoEl.innerHTML = processInfo;

                // Server Stats
                const serverStatsEl = document.getElementById('serverStats');
                const serverStats = '<pre>Hostname: ' + data.serverStats.hostname + '\\n' +
                    'Architecture: ' + data.serverStats.arch + '\\n' +
                    'CPU Cores: ' + data.serverStats.cpus + '\\n' +
                    'Total Memory: ' + Math.round(data.serverStats.totalMem / 1024 / 1024 / 1024) + ' GB\\n' +
                    'Free Memory: ' + Math.round(data.serverStats.freeMem / 1024 / 1024 / 1024) + ' GB\\n' +
                    'Load Average: ' + data.serverStats.loadAvg.join(', ') + '\\n' +
                    'OS Type: ' + data.serverStats.type + '\\n' +
                    'OS Release: ' + data.serverStats.release + '\\n' +
                    'Network Interfaces: ' + Object.keys(data.serverStats.networkInterfaces).join(', ') + '</pre>';
                serverStatsEl.innerHTML = serverStats;
            }

            function toggleCollapsible() {
                const content = document.getElementById('technicalDetails');
                content.classList.toggle('active');

                if (content.classList.contains('active')) {
                    loadTechnicalDetails();
                }
            }

            // Carica il counter all'avvio
            loadCounter();

            // Aggiorna ogni 5 secondi
            setInterval(loadCounter, 5000);
        </script>
    </body>
    </html>
  `);
});

// API per gestire il counter
app.get('/api/counter', (req, res) => {
  // Inizializza il counter di sessione se non esiste
  if (!req.session.counter) {
    req.session.counter = 0;
    log('INFO', 'New session counter initialized', { sessionId: req.session.id });
  }

  const responseData = {
    sessionCounter: req.session.counter,
    globalCounter: globalCounter,
    sessionId: req.session.id,
    serverInfo: {
      pid: process.pid,
      port: PORT,
      hostname: require('os').hostname(),
      uptime: process.uptime()
    }
  };

  log('INFO', 'Counter state retrieved', responseData);
  res.json(responseData);
});

app.post('/api/counter', (req, res) => {
  const { action } = req.body;

  // Inizializza il counter di sessione se non esiste
  if (!req.session.counter) {
    req.session.counter = 0;
    log('INFO', 'New session counter initialized', { sessionId: req.session.id });
  }

  const oldValue = req.session.counter;

  // Gestisci le azioni
  switch (action) {
    case 'increment':
      req.session.counter++;
      globalCounter++;
      break;
    case 'decrement':
      req.session.counter--;
      globalCounter--;
      break;
    case 'reset':
      req.session.counter = 0;
      break;
    default:
      log('WARN', 'Invalid action attempted', { action, sessionId: req.session.id });
      return res.status(400).json({ error: 'Azione non valida' });
  }

  log('INFO', 'Counter updated', {
    sessionId: req.session.id,
    action: action,
    oldValue: oldValue,
    newValue: req.session.counter,
    globalCounter: globalCounter
  });

  const responseData = {
    sessionCounter: req.session.counter,
    globalCounter: globalCounter,
    sessionId: req.session.id,
    serverInfo: {
      pid: process.pid,
      port: PORT,
      hostname: require('os').hostname(),
      uptime: process.uptime()
    }
  };

  res.json(responseData);
});

// Route per informazioni sul server
app.get('/api/info', (req, res) => {
  const infoData = {
    serverInfo: {
      pid: process.pid,
      hostname: require('os').hostname(),
      uptime: process.uptime(),
      nodeVersion: process.version,
      platform: process.platform
    },
    sessionId: req.session.id,
    sessionCounter: req.session.counter || 0,
    globalCounter: globalCounter
  };

  log('INFO', 'Server info requested', infoData);
  res.json(infoData);
});

// Route per statistiche sessioni attive
app.get('/api/stats', (req, res) => {
  const stats = {
    globalCounter: globalCounter,
    serverInfo: {
      pid: process.pid,
      hostname: require('os').hostname(),
      uptime: process.uptime(),
      memoryUsage: process.memoryUsage()
    },
    timestamp: new Date().toISOString()
  };

  log('INFO', 'Stats requested', stats);
  res.json(stats);
});

// Route per invalidare la sessione
app.post('/api/session/invalidate', (req, res) => {
  const oldSessionId = req.session.id;
  const oldCounter = req.session.counter || 0;

  // Distruggi la sessione corrente
  req.session.destroy((err) => {
    if (err) {
      log('ERROR', 'Session destruction failed', { error: err.message, sessionId: oldSessionId });
      return res.status(500).json({ success: false, error: 'Errore durante invalidazione sessione' });
    }

    log('INFO', 'Session invalidated', {
      oldSessionId: oldSessionId,
      oldCounter: oldCounter
    });

    // La nuova sessione verrà creata automaticamente alla prossima richiesta
    res.json({
      success: true,
      message: 'Sessione invalidata con successo',
      oldSessionId: oldSessionId,
      newSessionId: 'Will be created on next request'
    });
  });
});

// Route per dettagli tecnici completi
app.get('/api/technical', (req, res) => {
  const technicalData = {
    env: process.env,
    process: {
      pid: process.pid,
      platform: process.platform,
      version: process.version,
      uptime: process.uptime(),
      cwd: process.cwd(),
      execPath: process.execPath,
      memoryUsage: process.memoryUsage(),
      cpuUsage: process.cpuUsage(),
      argv: process.argv
    },
    serverStats: {
      hostname: require('os').hostname(),
      arch: require('os').arch(),
      cpus: require('os').cpus().length,
      totalMem: require('os').totalmem(),
      freeMem: require('os').freemem(),
      loadAvg: require('os').loadavg(),
      type: require('os').type(),
      release: require('os').release(),
      networkInterfaces: require('os').networkInterfaces()
    },
    sessionInfo: {
      sessionId: req.session.id,
      sessionCounter: req.session.counter || 0
    }
  };

  log('INFO', 'Technical details requested', {
    sessionId: req.session.id,
    requestedFields: Object.keys(technicalData)
  });

  res.json(technicalData);
});

// Health check
app.get('/health', (req, res) => {
  const healthData = { status: 'OK', timestamp: new Date().toISOString(), pid: process.pid };
  log('INFO', 'Health check', healthData);
  res.json(healthData);
});

// Gestione graceful shutdown
process.on('SIGTERM', () => {
  log('INFO', 'SIGTERM received, shutting down gracefully');
  process.exit(0);
});

process.on('SIGINT', () => {
  log('INFO', 'SIGINT received, shutting down gracefully');
  process.exit(0);
});

// Log degli errori non gestiti
process.on('uncaughtException', (err) => {
  log('ERROR', 'Uncaught Exception', { error: err.message, stack: err.stack });
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  log('ERROR', 'Unhandled Rejection', { reason: reason, promise: promise });
});

app.listen(PORT, () => {
  log('INFO', 'Counter App started successfully', {
    port: PORT,
    pid: process.pid,
    hostname: require('os').hostname(),
    nodeVersion: process.version
  });
  console.log(`🚀 Counter App in esecuzione su porta ${PORT}`);
  console.log(`📊 Accedi a http://localhost:${PORT}`);
  console.log(`📝 Log file: ${logFile}`);
  console.log(`🔧 API disponibili:`);
  console.log(`   GET  /api/counter - Ottieni stato counter`);
  console.log(`   POST /api/counter - Modifica counter`);
  console.log(`   GET  /api/info - Info server`);
  console.log(`   GET  /api/stats - Statistiche server`);
  console.log(`   GET  /api/technical - Dettagli tecnici completi`);
  console.log(`   POST /api/session/invalidate - Invalida sessione`);
  console.log(`   GET  /health - Health check`);
});